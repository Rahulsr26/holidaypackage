<?
error_reporting(1);
session_start();
header("location: add-package");
?>