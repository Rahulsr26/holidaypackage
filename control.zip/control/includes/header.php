 <div class="navbar-custom">
            <ul class="list-unstyled topnav-menu float-right mb-0">

                <li class="dropdown notification-list">
                    <a class="nav-link dropdown-toggle nav-user mr-0 waves-effect waves-light" data-toggle="dropdown"
                        href="#" role="button" aria-haspopup="false" aria-expanded="false">
                        <img src="assets/images/users/avatar-4.jpg" alt="user-image" class="rounded-circle">
                        <span class="pro-user-name ml-1">
                            Administrator  <i class="mdi mdi-chevron-down"></i>
                        </span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right profile-dropdown ">
                        <a href="logout" class="dropdown-item notify-item">
                            <i class="dripicons-power"></i>
                            <span>Logout</span>
                        </a>

                    </div>
                </li>


            </ul>


        </div>