 <footer class="footer">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-6">
                           &copy copyrights <?=date("Y")?> <?=PROJECT_TITLE?> all rights reserved.
                        </div>
                        <div class="col-md-6">
                           
                        </div>
                    </div>
                </div>
            </footer>