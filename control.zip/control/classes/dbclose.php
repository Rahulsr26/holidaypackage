<?
$mysqli -> close();