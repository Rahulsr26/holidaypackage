# Bootstrap tagsinput example

A Pen created on CodePen.io. Original URL: [https://codepen.io/Aviw/pen/YzzZYaL](https://codepen.io/Aviw/pen/YzzZYaL).

Working sample of https://bootstrap-tagsinput.github.io/bootstrap-tagsinput/examples/